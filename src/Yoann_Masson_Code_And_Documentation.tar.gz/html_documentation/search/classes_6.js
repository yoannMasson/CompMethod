var searchData=
[
  ['solver',['Solver',['../classSolver.html',1,'']]]
];
