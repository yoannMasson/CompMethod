var searchData=
[
  ['richardson',['Richardson',['../classRichardson.html#a43802f7613bfd6074da2c823a6bbbb2c',1,'Richardson']]]
];
