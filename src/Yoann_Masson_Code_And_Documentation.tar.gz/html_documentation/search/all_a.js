var searchData=
[
  ['uniform_5fnorm',['uniform_norm',['../classMatrix.html#a43066c7fe6418aad40170b85415063e8',1,'Matrix::uniform_norm()'],['../classVector.html#a50b72131eaf3698a9876d99ab6912a32',1,'Vector::uniform_norm()']]]
];
