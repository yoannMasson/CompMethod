var searchData=
[
  ['_7esolver',['~Solver',['../classSolver.html#a14f7014dd6e46e3990dea30b5ad3c087',1,'Solver']]]
];
