var searchData=
[
  ['one_5fnorm',['one_norm',['../classMatrix.html#af4d468252f3ecbbcaa5726c76e332b4c',1,'Matrix::one_norm()'],['../classVector.html#a6752a90058ddef427ca6aed12946a737',1,'Vector::one_norm()']]],
  ['operator_2a',['operator*',['../classMatrix.html#aaa40c78e6b3bb5bbf572d35612dbf6a7',1,'Matrix::operator*(const Matrix &amp;a) const'],['../classMatrix.html#a843eebe2b6bd9d8091be600f685252cb',1,'Matrix::operator*(const Vector &amp;v) const']]],
  ['operator_2d',['operator-',['../classMatrix.html#a5f08ceb21dd13e2afa6c68afc73db1d3',1,'Matrix']]],
  ['operator_3d',['operator=',['../classMatrix.html#aea5a06385f646eb4a63929fae6fa3e14',1,'Matrix::operator=()'],['../classVector.html#ae48c467a9f65d60e2f7455aba4ca1239',1,'Vector::operator=()']]],
  ['operator_3d_3d',['operator==',['../classMatrix.html#a35097c20bcb1495b57d452db0d7b1f53',1,'Matrix::operator==()'],['../classVector.html#ade5fbd0cd01b034d1907e0c93433320c',1,'Vector::operator==()']]]
];
