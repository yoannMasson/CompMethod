var searchData=
[
  ['matrix',['Matrix',['../classMatrix.html',1,'Matrix'],['../classMatrix.html#a2dba13c45127354c9f75ef576f49269b',1,'Matrix::Matrix()'],['../classMatrix.html#a135a15de1126d735bb95fcc839d739d7',1,'Matrix::Matrix(int Nrows, int Ncols)'],['../classMatrix.html#a765f4dcb51b6829311cc3e7576388423',1,'Matrix::Matrix(const Matrix &amp;m)']]]
];
