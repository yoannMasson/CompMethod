var searchData=
[
  ['richardson',['Richardson',['../classRichardson.html',1,'']]]
];
