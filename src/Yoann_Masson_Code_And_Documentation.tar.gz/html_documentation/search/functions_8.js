var searchData=
[
  ['solver',['Solver',['../classSolver.html#a3a1edb79e38781d40e5be114c7a549ba',1,'Solver']]]
];
