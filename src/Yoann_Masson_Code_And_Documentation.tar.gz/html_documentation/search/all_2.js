var searchData=
[
  ['dufortfrankel',['DufortFrankel',['../classDufortFrankel.html',1,'DufortFrankel'],['../classDufortFrankel.html#ab0c732f705d9b0aa1df228670a74b651',1,'DufortFrankel::DufortFrankel()']]]
];
