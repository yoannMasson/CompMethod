var searchData=
[
  ['getcomputedsolution',['getComputedSolution',['../classSolver.html#aafe88ce4130c001052e5d93c1681f90f',1,'Solver']]],
  ['getd',['getD',['../classSolver.html#a3b4da24979dd1c316c860749bbf6e3af',1,'Solver']]],
  ['getdt',['getDT',['../classSolver.html#a560a332c3193d5709e1e5eb44bfaa322',1,'Solver']]],
  ['getdx',['getDX',['../classSolver.html#a6a05cda84ae4e3f3a187cf69f1407d81',1,'Solver']]],
  ['getl',['getL',['../classSolver.html#afb4f245f8c8109afb3301942d30b4544',1,'Solver']]],
  ['getncols',['getNcols',['../classMatrix.html#ae0a5f2154953b8d129a90b04f91d9079',1,'Matrix']]],
  ['getnrows',['getNrows',['../classMatrix.html#a711f84a1c62832d9d197d78c9855a276',1,'Matrix']]],
  ['getsize',['getSize',['../classVector.html#afbb7966ec4107c43ec15cccc47fcaef7',1,'Vector']]],
  ['gett',['getT',['../classSolver.html#a7a09182372f91099da1cba8b1527e4c7',1,'Solver']]],
  ['gettin',['getTin',['../classSolver.html#ac091deb09ce1bb4bf2f70b6af3a2d6c2',1,'Solver']]],
  ['gettsur',['getTsur',['../classSolver.html#a652cc726a9f3e46239e3a2953e95495c',1,'Solver']]]
];
