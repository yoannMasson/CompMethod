var searchData=
[
  ['dufortfrankel',['DufortFrankel',['../classDufortFrankel.html',1,'']]]
];
