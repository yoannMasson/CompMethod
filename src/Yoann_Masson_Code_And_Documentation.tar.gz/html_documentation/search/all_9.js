var searchData=
[
  ['transpose',['transpose',['../classMatrix.html#a759661b75b9681f3a89ff75e27933b3a',1,'Matrix']]],
  ['two_5fnorm',['two_norm',['../classMatrix.html#aac496af05ec7aa26afc2b9c6d0ab8b66',1,'Matrix::two_norm()'],['../classVector.html#a4f501290a50d057bb6c57ea64d7e70a4',1,'Vector::two_norm()']]]
];
